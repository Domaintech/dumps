<?php
	include_once 'inc/all.php';

	if(login())
	{
		header("location:home.php");
		exit();
	}

	if(isset($_POST['ok']))
	{
		//var_dump($_POST);
		$matric = get_post('matric');
		$password = get_post('password');
		$sql = mysql_query("SELECT matric FROM students WHERE matric='$matric' and password='$password'") or die(mysql_error());
		$n = mysql_num_rows($sql);
		if($n == 0){
			set_flash("Invalid details, check and try again","danger");
			header("location:index.php");
			exit();
		}else{
			$_SESSION['matric'] = $matric;
			header("location:home.php");
			exit();
		}
		exit();		
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>The Federal Polytechnic Ede - Clearance Portal</title>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="IE=Edge"/> 		
	<meta name="viewport" content="width=device-width,initial-scale=1.0" />	
	<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="lib/font-awesome/font-awesome.min.css">
</head>
<body>
<style>
body{
	height: 50%;
	background-image: url(img/sch2.jpg);
	background-position: center;
	background-repeat: no-repeat;
}
</style>





<?php
	include_once 'nav.php';
?>
<section id="main">

	


<div class="container">
	<div class="col-md-6">
	<img   src="img/index.jpg"class="img-responsive" style="width:1000px; height:300px;">

			<div   class="intro">
				<h2>The Federal Polytechnic Ede</h2>
				<h2>Clearance Application Portal</h2>
					<h3 class="text-muted">
					New Applicant? <a href="apply.php">Apply Here</a>
				</h3>
			</div>
		</div>
		<div class="col-md-6">
			<div class="panel panel-info">
				<div class="panel-heading"><h5>Student Login</h5></div>
				
					<center>
						<img width="1200" style=" height:190px"  src="img/index2.jpg" class="img-responsive">
					</center>
					
					<div class="separator">&nbsp;</div>
					<form action="" method="post" role="form" class="has-success">
						<?php flash(); ?>
						<div class="form-group">
							<label>Matric No</label>
							<input type="text" name="matric" class="form-control" required="" placeholder="Matric Number">
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="password" name="password" class="form-control" required="" placeholder="Password">
						</div>
						<class="panel-title text-center">
						<div class="form-group">
							<input type="submit" name="ok" class="btn-success" value="Login">
						</div>						
					</form>					
					<p>
						<h4><a href="apply.php">Apply for clearance</h4></a>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
</section>
</div>
<section id="footer">
	&copy; The Federal Polytechnic Ede
</section>
<script type="text/javascript" src="lib/jquery/jquery.min.js"></script>
<script type="text/javascript" src="lib/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<body bgcolor="">
	
</body>
</body>

</html>