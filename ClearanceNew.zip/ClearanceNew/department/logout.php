<?php
	session_start();
	unset($_SESSION['depart']);
	header("location:../index.php");
	exit();
?>