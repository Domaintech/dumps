<?php
	session_start();
	unset($_SESSION['bursary']);
	header("location:../index.php");
	exit();
?>