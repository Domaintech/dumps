<?php
	session_start();
	unset($_SESSION['hostel']);
	header("location:../index.php");
	exit();
?>