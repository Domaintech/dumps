<?php
	include_once 'inc/all.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>About Developer</title>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="IE=Edge"/> 		
	<meta name="viewport" content="width=device-width,initial-scale=1.0" />	
	<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="lib/font-awesome/font-awesome.min.css">
</head>
<body>
<style>
body{
	height: 50%;
	background-image: url(img/sch2.jpg);
	background-position: center;
	background-repeat: no-repeat;
}
</style>





<?php
	include_once 'nav.php';
?>

<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1 page">

			<h3 class="page-header"></h3>
		</div>
	</div>
</div>

	<section id="main">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-sm-12 col-xs-12">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<center><h3><class="panel-title text-center">Supervised By</center></h3>
						</div>
						<div class="panel-body">
							<ul class="list-unstyled text-center text-danger">
								<h3><li>MR SUPERVISOR</li></h3></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-xs-12 col-sm-12">
					 <h2 div class="panel panel-primary"></h2><h2>
						<div class="panel-heading">
							<h2 class="text-center text-capitalize">Project Developed by:</h2>
						</div>
						<div class="panel-body">
							<table class="table table-bordered">
								<thead>
									<tr>
										<td>Name</td>
										<td>Matric No</td>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>LAWAL MORZUQ ADELEKE</td>
										<td>CS20190108879</td>
									</tr>
									<tr>
										<td>LAWAL MORZUQ ADELEKE</td>
										<td>CS20190106565</td>
									</tr>
									<tr>
										<td>LAWAL MORZUQ ADELEKE</td>
										<td>CS20190100045</td>
									</tr>
									<tr><td></td><td></td></tr>
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


<section id="footer">
	&copy; The Federal Polytechnic Ede 2022
</section>
<script type="text/javascript" src="lib/jquery/jquery.min.js"></script>
<script type="text/javascript" src="lib/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>