-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 05, 2019 at 07:49 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project_clearance`
--
CREATE DATABASE IF NOT EXISTS `project_clearance` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `project_clearance`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `name`) VALUES
('admin', 'admin', 'Damilola');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE IF NOT EXISTS `application` (
  `rrr` varchar(100) NOT NULL,
  `matric` varchar(20) NOT NULL,
  `date_applied` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_approved` varchar(100) NOT NULL,
  `officer` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`rrr`, `matric`, `date_applied`, `status`, `id`, `date_approved`, `officer`) VALUES
('ddjghjgh796699', 'cs201701748', '1572425661', '2', 1, '1572425717', 'Damilola'),
('jntyrykryky67676767', 'CS201700021', '1572897494', '2', 2, '1572897524', 'Damilola');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matric` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `date_borrowed` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `price` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bursary`
--

CREATE TABLE IF NOT EXISTS `bursary` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `matric` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `date_borrowed` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bursary_admin`
--

CREATE TABLE IF NOT EXISTS `bursary_admin` (
  `password` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bursary_admin`
--

INSERT INTO `bursary_admin` (`password`, `username`, `name`) VALUES
('admin', 'admin', 'damilola');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `name` varchar(100) NOT NULL,
  `matric` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`name`, `matric`) VALUES
('COMPUTER ENGINNERING', ''),
('MECHANICAL ENGINEERING', ''),
('SURVEYING & GEO-INFORMATICS', ''),
('ARCHITECTURE', ''),
('BUILDING TECHNOLOGY', ''),
('OFFICE TECHNOLOGY MANAGEMENT', ''),
('COMPUTER SCIENCE', ''),
('MARKETING', ''),
('HOSPITALITY MANAGEMENT', ''),
('NUTRITION & DIATETICS', ''),
('ELECTRICAL/ELECTRONICS ENGINEERING', ''),
('STATISTICS', ''),
('GEOLOGY', ''),
('CIVIL ENGINEERING', ''),
('BUSINESS ADMINISTRATIVE', ''),
('QUANTITY SURVEY', '');

-- --------------------------------------------------------

--
-- Table structure for table `department1`
--

CREATE TABLE IF NOT EXISTS `department1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matric` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date_borrowed` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `department_admin`
--

CREATE TABLE IF NOT EXISTS `department_admin` (
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_admin`
--

INSERT INTO `department_admin` (`name`, `username`, `password`) VALUES
('Elijah', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `hostel`
--

CREATE TABLE IF NOT EXISTS `hostel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matric` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date_borrowed` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `price` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `hostel_admin`
--

CREATE TABLE IF NOT EXISTS `hostel_admin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostel_admin`
--

INSERT INTO `hostel_admin` (`username`, `password`, `name`) VALUES
('admin', 'admin', 'Timileyin');

-- --------------------------------------------------------

--
-- Table structure for table `library_admin`
--

CREATE TABLE IF NOT EXISTS `library_admin` (
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library_admin`
--

INSERT INTO `library_admin` (`name`, `username`, `password`) VALUES
('ayodeji', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `sport_admin`
--

CREATE TABLE IF NOT EXISTS `sport_admin` (
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sport_admin`
--

INSERT INTO `sport_admin` (`name`, `username`, `password`) VALUES
('Adewale', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `sports`
--

CREATE TABLE IF NOT EXISTS `sports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matric` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date_borrowed` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `price` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matric` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `level` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `on_campus` varchar(30) NOT NULL,
  `room_no` varchar(30) NOT NULL,
  `app_date` varchar(100) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `passport` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `matric`, `password`, `name`, `phone`, `level`, `department`, `address`, `email`, `gender`, `state`, `on_campus`, `room_no`, `app_date`, `semester`, `passport`) VALUES
(1, 'CS201701748', 'CS201701748', 'OKIKIADE VICTOR SAMUEL', '08139643139', 'ND 2 FT', 'COMPUTER SCIENCE', 'NO 54 OPPOSITE POLICE STATION, OFOSUN IDANRE ONDO STATE', '', 'Male', 'Ondo State', 'No', '', '1572425523', '', 'Screenshot_20191026-194137.png'),
(2, 'CS201700021', 'CS201700021', 'BAKARE ELIZABETH', '08141530208', 'ND 2 FT', 'COMPUTER SCIENCE', '46 Yakubu street Ikosi iketu lagos state', '', 'Female', 'Ondo State', 'No', '', '1572897423', '', 'IMG-20191104-WA0002[1].jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
