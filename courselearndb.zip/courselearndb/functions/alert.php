<?php
	echo '<script language="javascript">';
    echo 'alert("You need to login or register first before you can view this page")';
    echo '</script>';
    echo '<meta http-equiv="refresh" content="0;url=../index.php" />';

?>